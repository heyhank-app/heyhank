# Agent Platform Info

## Server
- Host: srv676018 (agent.markusstoeger.com)
- 8 Cores, 31 GB RAM
- Node 22, Bun, PM2, Nginx, Redis, PostgreSQL

## Agents
- Coding Agent: Full-stack development
- Monitoring Agent: Server health checks
- Marketing Agent: SEO, Ads, Analytics
- Content Agent: Social media, images, video
- Personal Agent: Email, calendar, reminders
- Agent Max 2.0: Autonomous meta-agent

## Key Directories
- Platform: /opt/agentplatform/
- Agent Configs: ~/.companion/agents/
- Shared Context: ~/.companion/shared-context/
