# Active Projects

Track active projects here. Each agent can read and update this file.

## Projects
<!-- Add projects as they come up -->
